# Express Wizard Create Form

## Prerequisites
1. Make sure you install all of the requirements inside of `package.json` - (Hint: `npm ????`)
2. Start up the `NodeJS` server (Hint: `nodemon ???.js`)
3. Make sure you have rows `INSERT`ed from the previous MySQL activity
4. Make sure `MySQL` is still running ;-) 

## TODO
1. Implement the `POST` route to actually `INSERT` our new wizard into the database. 
1. Redirect to the `/list` route after `INSERT`ing the new wizard.
 
### Bonus
* Fiqure out how to highlight the new wizard (hint: Look for `MySQL` last insert ID)