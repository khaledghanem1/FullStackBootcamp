# Express Wizard _Lit_ List

## Prerequisites
1. Make sure you install all of the requirements inside of `package.json` - (Hint: `npm ????`)
2. Start up the `NodeJS` server (Hint: `nodemon ???.js`)
3. Make sure you have rows `INSERT`ed from the previous MySQL activity
4. Make sure `MySQL` is still running

## TODO
1. Read through the TODOs and make a route that lists all of the wizards from the `MySQL` table. 